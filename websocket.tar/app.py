import socketio
from aiohttp import web

sio = socketio.AsyncServer(cors_allowed_origins='*')
app = web.Application()
sio.attach(app)

async def hadle_update(request):
    await sio.emit('atualizar_tela')
    return web.Response(text="Notificado com sucesso", status=200)

app.router.add_post('/notificar', hadle_update)

if __name__ == '__main__':
    web.run_app(app, host='0.0.0.0', port=8532)